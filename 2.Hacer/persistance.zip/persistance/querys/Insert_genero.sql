INSERT INTO Genero (IdGenero, Descr_, Activo, Actualizar) VALUES
(uuid_generate_v4(), 'Masculino', B'1', NOW()),
(uuid_generate_v4(), 'Femenino', B'1', NOW()),
(uuid_generate_v4(), 'No binario', B'1', NOW()),
(uuid_generate_v4(), 'Otro', B'1', NOW()),
(uuid_generate_v4(), 'Prefiere no decir', B'1', NOW());
