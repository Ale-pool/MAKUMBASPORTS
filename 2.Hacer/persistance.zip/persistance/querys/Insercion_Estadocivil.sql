INSERT INTO EstadoCivil (IdEstadoCivil, FechaCambio, TipoEstadoCivil, Descrip_, Activo, Actualizar) VALUES
(uuid_generate_v4(), '2021-01-15', 'Soltero', 'Estado civil actual', B'1', NOW()),
(uuid_generate_v4(), '2022-03-22', 'Casado', 'Estado civil actual', B'1', NOW()),
(uuid_generate_v4(), '2020-11-30', 'Divorciado', 'Estado civil actual', B'1', NOW()),
(uuid_generate_v4(), '2021-07-05', 'Viudo', 'Estado civil actual', B'1', NOW()),
(uuid_generate_v4(), '2023-02-18', 'Unión libre', 'Estado civil actual', B'1', NOW());
