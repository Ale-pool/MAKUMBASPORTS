INSERT INTO Documento (IdDocumento, Numero, FechaExpedicion, Lugar, Descrip_, Activo, Actualizar) VALUES
(uuid_generate_v4(), 1122334455, '2010-05-12', 'Medellín', 'Cédula de ciudadanía', B'1', NOW()),
(uuid_generate_v4(), 2233445566, '2012-08-21', 'Bogotá', 'Cédula de ciudadanía', B'1', NOW()),
(uuid_generate_v4(), 3344556677, '2015-11-03', 'La Plata', 'DNI', B'1', NOW()),
(uuid_generate_v4(), 4455667788, '2013-09-14', 'São Paulo', 'RG', B'1', NOW()),
(uuid_generate_v4(), 5566778899, '2017-02-07', 'Santiago', 'RUT', B'1', NOW());
