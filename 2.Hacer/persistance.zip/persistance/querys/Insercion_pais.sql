
INSERT INTO Pais (IdPais, Nombre, Activo, Actualizar) VALUES
(uuid_generate_v4(), 'Colombia', TRUE, NOW()),
(uuid_generate_v4(), 'Argentina', TRUE, NOW()),
(uuid_generate_v4(), 'Brasil', TRUE, NOW()),
(uuid_generate_v4(), 'Chile', TRUE, NOW()),
(uuid_generate_v4(), 'Perú', TRUE, NOW());

