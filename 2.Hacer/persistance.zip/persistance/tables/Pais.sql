CREATE TABLE Pais (
    IdPais UUID PRIMARY KEY,
    Nombre VARCHAR(255),
    Activo BOOLEAN,
    Actualizar TIMESTAMP
);