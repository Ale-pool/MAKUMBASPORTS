CREATE TABLE MetodoPago (
    IdMetodoPago UUID PRIMARY KEY,
    Descr_ VARCHAR(255),
    Activo BOOLEAN,
    Actualizar TIMESTAMP
);
