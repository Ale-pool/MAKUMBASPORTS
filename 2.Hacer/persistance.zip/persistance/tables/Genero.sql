CREATE TABLE Genero (
    IdGenero UUID PRIMARY KEY,
    Descr_ VARCHAR(255),
    Activo BIT(1),
    Actualizar TIMESTAMP
);
