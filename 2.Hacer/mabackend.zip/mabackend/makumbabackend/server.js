// const express = require('express');
// const app =  express();
// const cors = require('cors');


// app.use(cors());    

// app.get("/", (req, res) => {
//     res.json({message: "hola mundo"});
// });

// app.listen(8067, () =>  {
//     console.log("Server running on port 8067");
// })