    IdDocumento UUID PRIMARY KEY,
    Numero BIGINT,
    FechaExpedicion DATE,
    Lugar VARCHAR(255),
    Descrip_ VARCHAR(255),
    Activo BIT(1),
    Actualizar TIMESTAMP
);
